=== SLS Snippets ===
Contributors: starlabs
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.0.3
License: GPLv2 or later

CodePen-style snippets inside WordPress. Compose HTML/CSS/JS with optional Pug, Babel (TS/JSX), and SCSS via client-side compilers running in Web Workers. Embed via shortcode or block. Sandboxed iframe + CSP for safety.

== Shortcode ==
[sls_snippet id="123" height="420" autorun="true"]

== Notes ==
- This build supports **plain HTML/CSS/JS** only (no Pug/SCSS/TypeScript/JSX/TSX compilers).
- Use the **SLS Snippets → Help** page in WP Admin for usage, embedding, and troubleshooting tips.
