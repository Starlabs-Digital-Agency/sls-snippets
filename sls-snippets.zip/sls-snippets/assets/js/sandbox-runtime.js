// If you need to bootstrap inside the iframe, place helpers here.
// Reserved for future iframe helpers (e.g., console proxy). Not required in MVP.
